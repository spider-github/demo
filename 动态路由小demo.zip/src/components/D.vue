<template>
    <div>
      <h1>
        {{info}}
      </h1>
    </div>
</template>

<script>
    export default {
      name: "D",
      data(){
        return {
          info:'',
          data:{
            a:{
              info: 'A'
            },
            b:{
              info: 'B'
            },
            c:{
              info: 'C'
            }
          }
        }
      },
      // 监听路由变化的方法
      watch:{
        //监听$route的变化来捕捉路由跳转.
        '$route.path':{
          immediate:true,
          handler(){
            let path = this.$route.params.path;
            console.log(path)
            this.info = this.data[path].info;
          }
        }
      }

      // 路由拦截方法
      // created(){
      //   let path = this.$route.path.split('/').slice(-1)[0];
      //   console.log(path)
      //   this.info = this.data[path].info;
      // },
      // beforeRouteUpdate(to,from,next){
      //   let path = to.params.path;
      //   this.info = this.data[path].info;
      //   next();
      // }
    }
</script>
