<template>
  <div>
    <router-link to='/router/a'>首页</router-link>
    <router-link to='/router/b'>活动</router-link>
    <router-link to='/router/c'>新闻</router-link>
    <router-view/>
  </div>
</template>

<script>
    export default {
      name: "Router",
    }
</script>

<style scoped>
  a{
    text-decoration: none;
  }
</style>
