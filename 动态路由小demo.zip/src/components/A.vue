<template>
    <div>{{msg}}</div>
</template>

<script>
    export default {
        name: "A",
        data() {
          return {
            msg: "A"
          }
        }
    }
</script>

<style scoped>

</style>
