<template>
    <div>{{msg}}</div>
</template>

<script>
    export default {
        name: "C",
        data() {
          return {
            msg: "C"
          }
        }
    }
</script>

<style scoped>

</style>
