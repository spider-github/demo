<template>
    <div>{{msg}}</div>
</template>

<script>
    export default {
        name: "B",
        data() {
          return {
            msg: "B"
          }
        }
    }
</script>

<style scoped>

</style>
