<template>
  <div>
    <router-link v-for="(item,index) in linkList" :to='item.routerLink' :key="index">&nbsp;{{item.title}}</router-link>
    <router-view/>
  </div>
</template>

<script>
  export default {
    name: "DtRouter",
    data() {
      return {
        linkList: [
          {
            routerLink: '/dtrouter/a',
            title: '首页a'
          },
          {
            routerLink: '/dtrouter/b',
            title: '首页b'
          },
          {
            routerLink: '/dtrouter/c',
            title: '首页c'
          }
        ]
      }
    }
  }
</script>

<style scoped>
  a{
    text-decoration: none;
  }
</style>
