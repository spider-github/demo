import Vue from 'vue'
import Router from 'vue-router'

import A from '@/components/A'
import B from '@/components/B'
import C from '@/components/C'
import D from '@/components/D'
import Routers from '@/components/Router'
import DtRouter from '@/components/DtRouter'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path:'/router',
      component:Routers,
      children: [
        {
          path:'/router/a',
          component:A
        },
        {
          path:'/router/b',
          component:B
        },
        {
          path:'/router/c',
          component:C
        },
        {
          path: '/router',
          redirect: '/router/a'
        }
      ]
    },

    // 动态路由
    {
      path:'/dtrouter',
      component:DtRouter,
      children: [
        {
          path: '/dtrouter/:path',
          component: D
        },
        {
          path: '/dtrouter',
          redirect: '/dtrouter/a'
        }
      ]
    },


    {
      path: '/',
      redirect: '/router/'
    }
  ]
})
